# Gota Certa (versão instalável)

Dra. Mariana Abreu Costa

App que lê o papel hidrossensível pela câmera do celular. Roda direto no navegador e, depois de instalado, abre sem internet.

## Arquivos

- `index.html`: o app inteiro (interface e análise da imagem)
- `manifest.webmanifest`: nome, cores e ícones do app instalado
- `sw.js`: guarda o app no aparelho para uso offline
- `icon-*.png` e `apple-touch-icon.png`: ícones

## Como publicar

O app precisa estar em um endereço HTTPS para poder ser instalado. Qualquer hospedagem estática serve:

1. **Netlify Drop** (mais rápido): abra app.netlify.com/drop e arraste esta pasta.
2. **GitHub Pages**: suba os arquivos em um repositório e ative Pages em Settings > Pages.
3. **Cloudflare Pages** ou **Vercel**: crie um projeto estático apontando para esta pasta.

Mantenha todos os arquivos na mesma pasta.

## Como instalar no celular

- **Android (Chrome):** abra o endereço, toque em ⋮ e em "Instalar app" ou "Adicionar à tela inicial".
- **iPhone (Safari):** abra o endereço, toque em Compartilhar e em "Adicionar à Tela de Início".

Abra o app uma vez com internet. Isso guarda os arquivos e as fontes no aparelho. Depois disso ele funciona offline.

## Atualizar o app

Ao mudar o `index.html`, troque o número de `VERSION` em `sw.js` (por exemplo, `v15`). Os aparelhos pegam a nova versão na próxima vez que abrirem o app com internet.

## Câmera guiada e confiança da leitura

- A **Câmera guiada** mostra uma moldura e avisa em tempo real se o papel está inteiro, a distância, o ângulo e o foco. Quando tudo fica verde, ela fotografa sozinha (dá para desligar a opção Automática e usar o botão).
- A câmera guiada só abre em endereço HTTPS e com permissão da câmera. Sem isso, o botão **Câmera do celular** continua funcionando.
- O app corrige a **perspectiva** do papel: uma foto um pouco inclinada ainda dá leitura certa.
- A **Confiança da leitura** (0 a 100) avalia resolução, nitidez, luz, inclinação, cobertura e número de gotas, e diz o que melhorar. Abaixo de 50, refaça a foto antes de decidir.
- A nota vai para o histórico e para a planilha.

## Condições, estatísticas e laudo

- **Condições da aplicação** (opcional): operador, bico, temperatura, umidade, vento, taxa, vazão, pressão e velocidade. O app calcula o **Delta T** e avisa sobre vento e evaporação. As faixas são referências comuns de campo: confirme com a bula e com o agrônomo.
- Depois da leitura aparecem **estatísticas completas** (mínimo, DV0,1, DMN, média, DMV, DV0,9, máximo, amplitude, quartis), gráficos por classe de 100 µm com acumulado, **índices** (homogeneidade, distribuição, sobreposição) e o **volume depositado estimado** em L/ha.
- **Clima automático:** digite a cidade (ex.: Rio Verde, GO) ou use a localização. O app busca temperatura, umidade e vento no Open-Meteo (precisa de internet) e mostra, hora a hora, os horários das próximas 24 h com Delta T e vento adequados. Sem internet, digite à mão.
- Homogeneidade, distribuição e sobreposição são índices próprios do Gota Certa, não normas.
- **Gerar laudo em PDF** cria um arquivo de 2 páginas no aparelho, com as imagens do papel, resultados e condições.
- Tudo isso entra no histórico e na planilha.

## Perfis de calibração

- Em **Ajustes de leitura**, digite um nome (por exemplo, "Fungicida com óleo") e toque em **Salvar perfil**. O perfil guarda tipo de aplicação, sensibilidade, fator de espalhamento e tamanho do papel.
- Escolha um perfil na lista para aplicar tudo de uma vez. Se você mudar um ajuste depois, o app avisa que está diferente do perfil.
- O nome do perfil vai para o histórico, a planilha e o laudo em PDF. Cada usuário tem os próprios perfis neste aparelho.
- O app não sabe qual é o espalhamento certo de cada calda: esse valor sai de comparar a leitura com um software de referência.

## Comparar leituras

- No histórico, marque **Comparar** em duas leituras. O app mostra as duas lado a lado (a mais antiga como "Antes" e a mais recente como "Depois") e a mudança em cada indicador.
- Serve para ver o efeito de trocar o bico, a pressão ou a velocidade. O app avisa se uma leitura tem confiança abaixo de 50, se são talhões diferentes ou se a densidade mudou menos de 10 %.

## Registro da calda

- Em **Calda desta aplicação** você informa o volume do tanque, o pH da calda (e da água, se quiser) e lista os produtos na ordem em que os coloca no tanque, com a dose de cada um.
- O app **só faz a conta**: com a taxa (L/ha) ele calcula a área por tanque e a quantidade de cada produto por tanque. Ele não sugere doses nem ordem de mistura. Confira sempre na bula e no receituário agronômico.
- O registro vai para o histórico, a planilha e uma terceira página do laudo em PDF.

## GPS e mapa dos talhões

- **Marcar local (GPS):** antes de salvar uma leitura, guarda a latitude, a longitude e a precisão do GPS. Vão para o histórico e para a planilha.
- **Marcar contorno do talhão:** preencha Fazenda e Talhão, caminhe pelos cantos e toque em Adicionar ponto aqui em cada um (precisão pior que 30 m é recusada). Ao fechar, o app calcula a área em hectares.
- **Mapa dos talhões:** mostra os contornos e os pontos das leituras (verde, amarelo ou vermelho). Não tem fundo de satélite, mas funciona sem internet. Toque em um ponto para ver a leitura.
- A área vem de poucos pontos de GPS de celular: serve como estimativa, não como medição topográfica.

## Login e histórico

- O login é feito no aparelho: nome de usuário e PIN de 4 a 6 números. Vários usuários podem usar o mesmo celular.
- Cada usuário tem o próprio histórico de leituras, com fazenda, talhão e observação.
- "Exportar para Excel" gera um arquivo CSV com o histórico (ou só a fazenda filtrada). O Excel abre o arquivo direto.
- Os dados ficam só neste aparelho, não vão para nenhum servidor. Se limpar os dados do navegador ou esquecer o PIN, não há recuperação. Exporte a planilha de vez em quando como cópia.
- Este login separa os históricos de cada pessoa, mas não protege contra quem tiver acesso ao aparelho desbloqueado. Para contas na nuvem, com histórico em vários aparelhos, o caminho é um serviço como o Supabase.

## Observações

- A câmera só abre em HTTPS (ou em localhost para testes).
- Os ajustes (tipo de aplicação, sensibilidade, fator de espalhamento, tamanho do papel) ficam salvos no aparelho.
- Os resultados são estimativas. Compare com um software de referência antes de decidir.

## Caderno de aplicação: pH e compatibilidade

Em "Calda desta aplicação" você informa o pH da calda e da água. O app compara o pH com uma faixa de referência geral (5,0 a 6,5) e avisa quando a água é alcalina (pH 7,5 ou mais). Se houver mais de um produto, ele checa cada par de produtos na **sua planilha de compatibilidade**, que você importa em "Base de compatibilidade". O app não traz dados próprios: usa só o que está na sua planilha e mostra "Sem dados" quando o par não existe nela.

Como importar: salve a planilha como CSV (Excel ou Numbers: Arquivo, Salvar como ou Exportar, CSV). Colunas aceitas: Biológico, Produto, Marca, Princípio ativo, Resultado, Fonte e Observação. Se a planilha não tiver a coluna Biológico, digite o nome do biológico no campo indicado antes de importar. Pode importar várias planilhas (uma por biológico). Há um "Baixar modelo de planilha" no próprio app.

O resultado vai para o histórico, para a planilha de Excel (duas colunas novas) e para a página da calda no laudo.

## Ordem de mistura

Importe também uma planilha de ordem de mistura (CSV com as colunas Produto, Fabricante, Tipo, Formulação, Ordem, Pré-diluição e Observações). O app reconhece sozinho que é uma planilha de ordem. Com dois ou mais produtos na calda, ele mostra a ordem sugerida pela sua base, com pré-diluição e observações, e o botão "Aplicar esta ordem na lista" reorganiza os produtos sem perder as doses. Produtos que não estão na sua base ficam no fim, marcados "sem dado de ordem". A ordem sugerida vai para o laudo e para o Excel. O app não cria regras próprias: confira sempre a bula e faça o teste de calda.
